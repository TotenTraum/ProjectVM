var searchData=
[
  ['xorcommand_0',['XorCommand',['../classXorCommand.html',1,'']]]
];
