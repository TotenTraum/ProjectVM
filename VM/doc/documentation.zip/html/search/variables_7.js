var searchData=
[
  ['sf_0',['SF',['../structPSW_1_1Flags.html#a200589bd2fc99749286790711604fe14',1,'PSW::Flags']]]
];
