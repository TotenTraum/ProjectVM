var indexSectionsWithContent =
{
  0: "abcdefijlmnoprstuvxz",
  1: "abcdefijlmnoprstuvx",
  2: "ceoprs",
  3: "abcimopstz",
  4: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "related"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Функции",
  3: "Переменные",
  4: "Друзья"
};

