var searchData=
[
  ['setflags_0',['setFlags',['../classArifmeticCommands.html#ae6e182698e1db4ef68628a37e85d7e64',1,'ArifmeticCommands::setFlags()'],['../classNotCommand.html#a939895fb3de64d21fde21a6bfca35e90',1,'NotCommand::setFlags()']]],
  ['setof_1',['setOF',['../classArifmeticCommands.html#a836818fa9719dfbc39fd61a562281ef8',1,'ArifmeticCommands::setOF()'],['../classIntAC.html#aa38a20f10b5cd25b6d98a332e82e079e',1,'IntAC::setOF()'],['../classFloatAC.html#a81afc6156947f3c88a1f841953b73f13',1,'FloatAC::setOF()']]],
  ['setsf_2',['setSF',['../classArifmeticCommands.html#a371a0f9bf19f568db25da9f4a01fcca7',1,'ArifmeticCommands::setSF()'],['../classIntAC.html#a32ee2086d8260487bb6f42f7149d86ff',1,'IntAC::setSF()'],['../classFloatAC.html#a0bc6823d33be6faf108d7b4e3af176c0',1,'FloatAC::setSF()']]],
  ['setzf_3',['setZF',['../classArifmeticCommands.html#ad4090d7323c4b93fea34b3040aab2f4b',1,'ArifmeticCommands::setZF()'],['../classIntAC.html#a744e2660ad4fb48def7fca832772586c',1,'IntAC::setZF()'],['../classFloatAC.html#a38c11c57daa39d2b131f3ece38492618',1,'FloatAC::setZF()']]]
];
